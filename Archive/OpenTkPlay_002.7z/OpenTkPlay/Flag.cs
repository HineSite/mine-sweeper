﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK.Graphics.OpenGL;

namespace OpenTkPlay
{
   class Flag
   {
      private RectangleF _bounds;
      private float _pixelWidth = 0;

      public Flag(RectangleF bounds, float pixelWidth)
      {
         UpdateBounds(bounds);
         _pixelWidth = pixelWidth;
      }

      public Flag UpdateBounds(RectangleF bounds)
      {
         _bounds = bounds;

         return this;
      }

      public void Draw()
      {
         RectangleF bounds = new RectangleF(_bounds.X, _bounds.Y, _bounds.Width, _bounds.Height);

         float coordWidth = (bounds.Width / 2f);
         float coordHeight = (bounds.Height / 2f);

         float poleWidth = _pixelWidth;
         float poleHeight = (20 * _pixelWidth);
         float flagWidth = (9 * _pixelWidth);
         float flagHeight = (9 * _pixelWidth);
         float totalWidth = (poleWidth + flagWidth);
         float totalHeight = poleHeight;

         /*GL.PushMatrix();

         GL.Translate(bounds.X + coordWidth, bounds.Y - coordHeight, 0);

         GL.Begin(PrimitiveType.Quads);
         GL.Color3(Color.White);
         GL.Vertex2(-coordWidth, coordHeight);
         GL.Vertex2(-coordWidth, -coordHeight);
         GL.Vertex2(coordWidth, -coordHeight);
         GL.Vertex2(coordWidth, coordHeight);
         GL.End();

         GL.PopMatrix();*/

         GL.PushMatrix();

         GL.Translate(bounds.X + coordWidth + ((_bounds.Width - totalWidth) / 2f), bounds.Y - coordHeight - ((_bounds.Height - totalHeight) / 2f), 0);

         { // Pole
            GL.Begin(PrimitiveType.Lines);
            GL.Color3(Color.Black);
            GL.Vertex2(-coordWidth, coordHeight);
            GL.Vertex2(-coordWidth, coordHeight - poleHeight);
            GL.End();
         }

         { // Flag
            GL.Begin(PrimitiveType.Triangles);
            GL.Color3(Color.DarkRed);
            GL.Vertex2(-coordWidth + _pixelWidth, coordHeight - _pixelWidth);
            GL.Vertex2(-coordWidth + _pixelWidth, coordHeight - _pixelWidth - flagHeight);
            GL.Vertex2(-coordWidth + _pixelWidth + flagWidth, coordHeight - _pixelWidth - (flagHeight / 2f));
            GL.End();
         }

         GL.PopMatrix();

         //GL.Begin(PrimitiveType.Quads);
         //GL.Color3(innerColor);
         //GL.Vertex2(-coordWidth, coordHeight);
         //GL.Vertex2(-coordWidth, -coordHeight);
         //GL.Vertex2(coordWidth, -coordHeight);
         //GL.Vertex2(coordWidth, coordHeight);
         //GL.End();

      }
   }
}
