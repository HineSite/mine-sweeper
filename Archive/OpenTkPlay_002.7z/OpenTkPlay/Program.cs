﻿using System.Collections.Generic;
using System.Drawing;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using OpenTK.Input;

namespace OpenTkPlay
{
   public class Program
   {
      private Program() { }

      static void Main(string[] args)
      {
         using (new Game()) { }
      }
   }
}
