﻿using System;
using System.Collections.Generic;
using System.Drawing;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using OpenTK.Input;
using System.Linq;

namespace OpenTkPlay
{
   class Game : GameWindow
   {
      private Tile[,] _tiles = new Tile[16, 16];
      private RectangleF _trueBounds;

      public Game()
      {
         ClientSize = new Size(400, 400);
         WindowBorder = OpenTK.WindowBorder.Fixed;

         GL.MatrixMode(MatrixMode.Projection);
         GL.LoadIdentity();
         GL.Ortho(-1.0, 1.0, -1.0, 1.0, 0.0, 1.0); // Left, Right, Bottom, Top

         Load += OnLoad;
         Resize += OnWindowResize;
         UpdateFrame += OnFrameUpdate;
         RenderFrame += OnFrameRender;
         Move += OnWindowMove;

         Run(60.0); // Run the game at 60 updates per second
      }

      public void OnWindowResize(object sender, EventArgs e)
      {
         GL.Viewport(0, 0, Width, Height);

         int borderWidth = ((Bounds.Width - ClientRectangle.Width) / 2);
         int titleHeight = (Bounds.Height - ClientRectangle.Width - borderWidth);

         _trueBounds = new RectangleF(Bounds.X + borderWidth, Bounds.Y + titleHeight, ClientRectangle.Width, ClientRectangle.Height);
      }

      public void OnWindowMove(object sender, EventArgs e)
      {
         GL.Viewport(0, 0, Width, Height);

         int borderWidth = ((Bounds.Width - ClientRectangle.Width) / 2);
         int titleHeight = (Bounds.Height - ClientRectangle.Width - borderWidth);

         _trueBounds = new RectangleF(Bounds.X + borderWidth, Bounds.Y + titleHeight, ClientRectangle.Width, ClientRectangle.Height);
      }

      public void OnLoad(object sender, EventArgs e)
      {
         // setup settings, load textures, sounds
         VSync = VSyncMode.On;

         { // Create the tile set
            float xPos = -1f;
            float yPos = 1f;
            float width = (2 / 16f);
            float height = (2 / 16f);

            for (int row = 0; row < 16; row++)
            {
               for (int col = 0; col < 16; col++)
               {
                  _tiles[row, col] = new Tile(new RectangleF(xPos, yPos, width, height));

                  xPos += width;
               }

               xPos = -1f;
               yPos -= height;
            }
         }

         { // Mine the field
            Random random = new Random();
            int mines = 40;
            int row = 0;
            int col = 0;

            while (mines != 0)
            {
               row = random.Next(0, 15);
               col = random.Next(0, 15);

               if (!_tiles[row, col].Mined)
               {
                  _tiles[row, col].Mined = true;

                  mines--;
               }
            }

            Tile.OnMineDetonated += OnMineDetonated;
         }

         { // Find and set the tile siblings
            Tile[] siblings = null;

            for (int row = 0; row < 16; row++)
            {
               for (int col = 0; col < 16; col++)
               {
                  siblings = new Tile[8];
                  siblings[0] = (row > 0 && col > 0) ? _tiles[row - 1, col - 1] : null;
                  siblings[1] = (row > 0) ? _tiles[row - 1, col - 0] : null;
                  siblings[2] = (row > 0 && col < 15) ? _tiles[row - 1, col + 1] : null;
                  siblings[3] = (col < 15) ? _tiles[row - 0, col + 1] : null;
                  siblings[4] = (row < 15 && col < 15) ? _tiles[row + 1, col + 1] : null;
                  siblings[5] = (row < 15) ? _tiles[row + 1, col - 0] : null;
                  siblings[6] = (row < 15 && col > 0) ? _tiles[row + 1, col - 1] : null;
                  siblings[7] = (col > 0) ? _tiles[row - 0, col - 1] : null;

                  _tiles[row, col].Siblings = (siblings.Where(o => o != null).ToArray());
               }
            }
         }
      }

      public void OnMineDetonated(Tile tile)
      {
         for (int row = 0; row < 16; row++)
         {
            for (int col = 0; col < 16; col++)
            {
               _tiles[row, col].Reveal();
            }
         }
      }

      public void OnFrameUpdate(object sender, FrameEventArgs e)
      {
         if (!Focused)
            return;

         // add game logic, input handling
         if (Keyboard[Key.Escape])
         {
            Exit();
         }

         OpenTkPlay.Mouse.Update(_trueBounds);
      }

      public void OnFrameRender(object sender, FrameEventArgs e)
      {
         // render graphics
         GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit);
         
         for (int row = 0; row < 16; row++)
         {
            for (int col = 0; col < 16; col++)   
            {
               if (_tiles[row, col] != null)
                  _tiles[row, col].Draw();
            }
         }

         SwapBuffers();
      }
   }
}
