﻿using System;
using System.Collections.Generic;
using System.Drawing;
using OpenTK;
using OpenTK.Graphics.OpenGL;
using OpenTK.Input;
using System.Linq;
using System.Drawing.Imaging;

namespace OpenTkPlay
{
   class Game : GameWindow
   {
      private const int HEADER_HEIGHT = 0;
      private const int NUM_MINES = 40;

      private Tile[,] _tiles = new Tile[16, 16];
      private RectangleF _trueBounds;
      private int _flaggedMines = 0;
      private bool _gameOver = false;
      private bool _gameWon = false;

      public Game()
      {
         ClientSize = new Size(400, 400 + HEADER_HEIGHT);
         WindowBorder = OpenTK.WindowBorder.Fixed;

         GL.MatrixMode(MatrixMode.Projection);
         GL.LoadIdentity();
         GL.Ortho(0.0f, ClientSize.Width, ClientSize.Height, 0.0f, 0.0f, 1.0f); // Left, Right, Bottom, Top

         Load += OnLoad;
         Resize += OnWindowResize;
         UpdateFrame += OnFrameUpdate;
         RenderFrame += OnFrameRender;
         Move += OnWindowMove;

         Run(60.0); // Run the game at 60 updates per second
      }

      public void OnWindowResize(object sender, EventArgs e)
      {
         GL.Viewport(0, 0, Width, Height);

         int borderWidth = ((Bounds.Width - ClientRectangle.Width) / 2);
         int titleHeight = (Bounds.Height - ClientRectangle.Height - borderWidth);

         _trueBounds = new RectangleF(Bounds.X + borderWidth, Bounds.Y + titleHeight, ClientRectangle.Width, ClientRectangle.Height);
      }

      public void OnWindowMove(object sender, EventArgs e)
      {
         GL.Viewport(0, 0, Width, Height);

         int borderWidth = ((Bounds.Width - ClientRectangle.Width) / 2);
         int titleHeight = (Bounds.Height - ClientRectangle.Width - borderWidth);

         _trueBounds = new RectangleF(Bounds.X + borderWidth, Bounds.Y + titleHeight, ClientRectangle.Width, ClientRectangle.Height);
      }

      public void OnLoad(object sender, EventArgs e)
      {
         // setup settings, load textures, sounds
         VSync = VSyncMode.On;

         { // Create the tile set
            float pixelWidth = 1;
            float width = ((ClientSize.Width / 16f) - pixelWidth);
            float height = width;
            float widthHalf = (width / 2);
            float heightHalf = (height / 2);
            float xPos = 0f;
            float yPos = HEADER_HEIGHT;

            for (int row = 0; row < 16; row++)
            {
               xPos = 0;

               for (int col = 0; col < 16; col++)
               {
                  _tiles[row, col] = new Tile(new RectangleF(xPos, yPos, width, height));

                  xPos += (width + pixelWidth);
               }

               yPos += (height + pixelWidth);
            }
         }

         { // Mine the field
            Random random = new Random();
            int mines = NUM_MINES;
            int row = 0;
            int col = 0;

            while (mines != 0)
            {
               row = random.Next(0, 15);
               col = random.Next(0, 15);

               if (!_tiles[row, col].Mined)
               {
                  _tiles[row, col].Mined = true;

                  mines--;
               }
            }

            Tile.OnMineDetonated += OnMineDetonated;
            Tile.OnFlagChanged += OnMineFlagChanged;
            Tile.OnClicked += OnMineClicked;
         }

         { // Find and set the tile siblings
            Tile[] siblings = null;

            for (int row = 0; row < 16; row++)
            {
               for (int col = 0; col < 16; col++)
               {
                  siblings = new Tile[8];
                  siblings[0] = (row > 0 && col > 0) ? _tiles[row - 1, col - 1] : null;
                  siblings[1] = (row > 0) ? _tiles[row - 1, col - 0] : null;
                  siblings[2] = (row > 0 && col < 15) ? _tiles[row - 1, col + 1] : null;
                  siblings[3] = (col < 15) ? _tiles[row - 0, col + 1] : null;
                  siblings[4] = (row < 15 && col < 15) ? _tiles[row + 1, col + 1] : null;
                  siblings[5] = (row < 15) ? _tiles[row + 1, col - 0] : null;
                  siblings[6] = (row < 15 && col > 0) ? _tiles[row + 1, col - 1] : null;
                  siblings[7] = (col > 0) ? _tiles[row - 0, col - 1] : null;

                  _tiles[row, col].Siblings = (siblings.Where(o => o != null).ToArray());
               }
            }
         }
      }

      public void OnMineDetonated(Tile tile)
      {
         _gameOver = true;

         for (int row = 0; row < 16; row++)
         {
            for (int col = 0; col < 16; col++)
            {
               _tiles[row, col].Reveal();
            }
         }
      }

      public bool WinConditionMet()
      {
         if (_flaggedMines != NUM_MINES)
            return false;

         for (int row = 0; row < 16; row++)
         {
            for (int col = 0; col < 16; col++)
            {
               if (_tiles[row, col].Active)
                  return false;
            }
         }

         return true;
      }

      public void OnMineFlagChanged(Tile tile, bool newState)
      {
         if (newState == true) // It is now flagged
         {
            _flaggedMines++;

            if (_flaggedMines == NUM_MINES) // Check for win condition
               _gameWon = _gameOver = WinConditionMet();
         }
         else
         {
            _flaggedMines--;
         }
      }

      public void OnMineClicked(Tile tile)
      {
         _gameWon = _gameOver = WinConditionMet();
      }

      public void OnFrameUpdate(object sender, FrameEventArgs e)
      {
         if (!Focused)
            return;

         // add game logic, input handling
         if (Keyboard[Key.Escape])
         {
            Exit();
         }

         OpenTkPlay.Mouse.Update(_trueBounds);
      }

      public void DrawHeader()
      {

      }

      public void OnFrameRender(object sender, FrameEventArgs e)
      {
         // render graphics
         GL.Clear(ClearBufferMask.ColorBufferBit | ClearBufferMask.DepthBufferBit | ClearBufferMask.AccumBufferBit);
         //GL.Disable(EnableCap.CullFace);
         //GL.Disable(EnableCap.DepthTest);
         GL.Enable(EnableCap.Blend);
         GL.BlendFunc(BlendingFactorSrc.SrcAlpha, BlendingFactorDest.OneMinusSrcAlpha);
         //GL.Disable(EnableCap.Lighting);
         //GL.ShadeModel(ShadingModel.Flat);
         GL.Enable(EnableCap.LineSmooth); // This is Optional 
         //GL.Enable(EnableCap.Normalize);  // These is critical to have
         //GL.Enable(EnableCap.RescaleNormal);
         

         // Background
         GL.Begin(PrimitiveType.Quads);
         GL.Color3(Color.LightGray);
         GL.Vertex2(0.0f, 0.0f);
         GL.Vertex2(0.0f, ClientSize.Height);
         GL.Vertex2(ClientSize.Width, ClientSize.Height);
         GL.Vertex2(ClientSize.Width, 0.0f);
         GL.End();

         for (int row = 0; row < 16; row++)
         {
            for (int col = 0; col < 16; col++)
            {
               if (_tiles[row, col] != null)
                  _tiles[row, col].Draw();
            }
         }

         if (_gameWon)
         {
            GL.Begin(PrimitiveType.Quads);
            GL.Color4(Color.FromArgb(224, Color.White));
            GL.Vertex2(0.0f, 0.0f);
            GL.Vertex2(0.0f, ClientSize.Height);
            GL.Vertex2(ClientSize.Width, ClientSize.Height);
            GL.Vertex2(ClientSize.Width, 0.0f);
            GL.End();

            GL.PushMatrix();

            GL.Translate(ClientSize.Width/2f, ClientSize.Height/2f, 0);

            TextWriter writer = new TextWriter(10);
            writer.AddLine("\"The supreme art of war is to subdue");
            writer.AddLine("           the enemy without fighting.\"");
            writer.AddLine("- Sun Tzu, The Art of War");
            writer.CreateTexture();
            writer.Draw();

            GL.PopMatrix();
         }

         SwapBuffers();
      }
   }
}
