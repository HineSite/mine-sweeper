﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using OpenTK.Graphics.OpenGL;

namespace OpenTkPlay
{
   class Tile
   {
      public delegate void OnMineDetonatedHandler(Tile detonatedTile);
      public delegate void OnFlagChangedHandler(Tile tile, bool newState);
      public delegate void OnClickHandler(Tile tile);

      public static event OnMineDetonatedHandler OnMineDetonated
      {
         add
         {
            _events["OnMineDetonated"] = (OnMineDetonatedHandler)_events["OnMineDetonated"] + value;
         }

         remove
         {
            _events["OnMineDetonated"] = (OnMineDetonatedHandler)_events["OnMineDetonated"] - value;
         }
      }
      public static event OnFlagChangedHandler OnFlagChanged
      {
         add
         {
            _events["OnFlagChanged"] = (OnFlagChangedHandler)_events["OnFlagChanged"] + value;
         }

         remove
         {
            _events["OnFlagChanged"] = (OnFlagChangedHandler)_events["OnFlagChanged"] - value;
         }
      }
      /// <summary>
      ///  Will only be called if this tile is not mined.
      /// </summary>
      public static event OnClickHandler OnClicked
      {
         add
         {
            _events["OnClicked"] = (OnClickHandler)_events["OnClicked"] + value;
         }

         remove
         {
            _events["OnClicked"] = (OnClickHandler)_events["OnClicked"] - value;
         }
      }

      private static Hashtable _events = new Hashtable();

      public Tile[] Siblings
      {
         get
         {
            return _siblings;
         }

         set
         {
            _siblings = value;

            foreach (Tile tile in value)
            {
               if (tile.Mined)
                  _minedSiblings++;
            }
         }
      }
      public bool Active
      {
         get
         {
            return (!_clicked && !_flagged) || (_flagged && !Mined);
         }
      }

      public bool Mined { get; set; }

      private RectangleF _bounds;
      private bool _clicked = false;
      private bool _flagged = false;
      private bool _revealed = false;
      private int _minedSiblings = 0;
      private Tile[] _siblings = null;

      public Tile(RectangleF bounds)
      {
         UpdateBounds(bounds);

         Mouse.OnLeftUp += OnLeftMouseUp;
         Mouse.OnRightUp += OnRightMouseUp;
      }

      public Tile UpdateBounds(RectangleF bounds)
      {
         _bounds = bounds;

         return this;
      }

      public void OnLeftMouseUp(MouseEventArgs mouseEventArgs)
      {
         if (_revealed || _clicked || _flagged)
            return;

         if (_bounds.IntersectsWith(mouseEventArgs.WindowPos))
            Click();
      }

      public void OnRightMouseUp(MouseEventArgs mouseEventArgs)
      {
         if (_revealed || _clicked)
            return;

         if (_bounds.IntersectsWith(mouseEventArgs.WindowPos))
         {
            _flagged = !_flagged;

            if (_events.ContainsKey("OnFlagChanged"))
               ((OnFlagChangedHandler)_events["OnFlagChanged"])(this, _flagged);
         }
      }

      public void Click()
      {
         if (_revealed || _clicked || _flagged)
            return;

         if (Mined)
         {
            if (_events.ContainsKey("OnMineDetonated"))
               ((OnMineDetonatedHandler)_events["OnMineDetonated"])(this);
         }
         else
         {
            _clicked = true;

            if (_events.ContainsKey("OnClicked"))
               ((OnClickHandler)_events["OnClicked"])(this);

            List<Tile> allSibs = new List<Tile>();

            foreach (Tile tile in Siblings)
            {
               if (!tile.Mined && tile._minedSiblings == 0)
               {
                  tile.Click();
                  allSibs.AddRange(tile.Siblings);
               }
            }

            foreach (Tile tile in allSibs)
            {
               if (!tile.Mined)
                  tile.Click();
            }
         }
      }

      public void Reveal()
      {
         _revealed = true;
      }

      public void Draw()
      {
         float coordWidthOrg = (_bounds.Width / 2f);
         float coordHeightOrg = (_bounds.Height / 2f);
         float coordWidth = coordWidthOrg;
         float coordHeight = coordHeightOrg;

         Color innerColor = (_clicked ? Color.LightGray : Color.White);

         if (_clicked && _minedSiblings > 0)
            innerColor = ColorTranslator.FromHtml("#dddddd");

         if (_revealed && Mined && !_flagged)
            innerColor = Color.DarkRed;

         GL.PushMatrix();

         GL.Translate(_bounds.X + coordWidthOrg, _bounds.Y + coordHeightOrg, 0);

         GL.Begin(PrimitiveType.Quads);
         GL.Color3(innerColor);
         GL.Vertex2(-coordWidth, coordHeight);
         GL.Vertex2(-coordWidth, -coordHeight);
         GL.Vertex2(coordWidth, -coordHeight);
         GL.Vertex2(coordWidth, coordHeight);
         GL.End();

         GL.PopMatrix();

         if (_flagged)
         {
            Flag flag = new Flag(_bounds);
            flag.Draw();

            if (_revealed && !Mined)
            {
               GL.PushMatrix();

               GL.Translate(_bounds.X + coordWidthOrg, _bounds.Y + coordHeightOrg, 0);

               GL.Begin(PrimitiveType.Lines);
               GL.Color3(Color.DarkRed);
               GL.Vertex2(-coordWidthOrg, coordHeightOrg);
               GL.Vertex2(coordWidthOrg, -coordHeightOrg);

               GL.Vertex2(-coordWidthOrg, -coordHeightOrg);
               GL.Vertex2(coordWidthOrg, coordHeightOrg);
               GL.End();

               GL.PopMatrix();
            }
         }

         if (_clicked && _minedSiblings > 0)
         {
            float numWidth = (_bounds.Width / 3.0f);
            float numHeight = (_bounds.Height / 2.5f);
            Color numColor = Color.Blue;

            switch (_minedSiblings)
            {
               case 2:
               {
                  numColor = Color.Green;

                  break;
               }

               case 3:
               {
                  numColor = Color.Red;

                  break;
               }

               case 4:
               {
                  numColor = Color.DarkBlue;

                  break;
               }

               case 5:
               {
                  numColor = Color.Black;

                  break;
               }

               case 6:
               {
                  numColor = Color.Turquoise;

                  break;
               }

               case 7:
               {
                  numColor = Color.DarkGreen;

                  break;
               }

               case 8:
               {
                  numColor = Color.DarkGray;

                  break;
               }
            }

            Number number = new Number(_minedSiblings, new RectangleF(_bounds.X + (coordWidth / 2f), _bounds.Y + (coordHeight / 2f), numWidth, numHeight), numColor);
            number.Draw();
         }
      }
   }
}
